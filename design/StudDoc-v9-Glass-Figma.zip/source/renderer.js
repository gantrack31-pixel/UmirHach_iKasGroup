(() => {
  const scene = window.STUDDOC_SCENE;
  const query = new URLSearchParams(location.search);
  const renderOnly = query.has('render');
  const root = document.getElementById('board');
  const viewport = document.getElementById('viewport');
  const select = document.getElementById('board-select');
  const svgns = 'http://www.w3.org/2000/svg';
  let selected = Math.max(0, Math.min(scene.boards.length - 1, Number(query.get('board')) || 0));
  if (renderOnly) document.body.classList.add('render');
  const px = n => `${n || 0}px`;
  const appendPath = (node, el) => {
    const svg = document.createElementNS(svgns, 'svg');
    svg.setAttribute('width', node.w); svg.setAttribute('height', node.h);
    svg.style.overflow = 'visible'; svg.style.display = 'block';
    const shape = document.createElementNS(svgns, node.closed ? 'polygon' : 'polyline');
    shape.setAttribute('points', node.points.map(p => p.join(',')).join(' '));
    shape.setAttribute('fill', node.fill || 'none'); shape.setAttribute('stroke', node.color || 'none');
    shape.setAttribute('stroke-width', node.width || 1); shape.setAttribute('stroke-linecap', 'round'); shape.setAttribute('stroke-linejoin', 'round');
    svg.append(shape); el.append(svg);
  };
  function make(node) {
    const el = document.createElement(node.type === 'bitmap' ? 'img' : 'div');
    el.className = `layer ${node.type}`;
    el.dataset.name = node.name;
    const style = el.style;
    Object.assign(style, { left: px(node.x), top: px(node.y), width: px(node.w), height: px(node.h) });
    if (node.opacity !== undefined) style.opacity = node.opacity;
    if (node.type === 'bitmap') { el.src = node.asset; el.alt = ''; el.draggable = false; }
    if (node.type === 'rect') {
      style.background = node.gradient ? `linear-gradient(${node.gradientDirection === 'horizontal' ? 'to right' : 'to bottom'}, ${node.gradient.map((c, i) => `${c} ${(node.gradientPositions?.[i] ?? i / (node.gradient.length - 1)) * 100}%`).join(',')})` : node.fill || 'transparent';
      style.borderRadius = px(node.r);
      if (node.stroke) style.border = `1px ${node.dash ? 'dashed' : 'solid'} ${node.stroke}`;
      if (node.backgroundBlur) { el.classList.add('glass'); style.backdropFilter = `blur(${node.backgroundBlur}px)`; style.webkitBackdropFilter = `blur(${node.backgroundBlur}px)`; }
      if (node.shadow) style.boxShadow = `${px(node.shadow.x)} ${px(node.shadow.y)} ${px(node.shadow.blur)} ${px(node.shadow.spread)} ${node.shadow.color}`;
    }
    if (node.type === 'path') appendPath(node, el);
    if (node.type === 'text') {
      Object.assign(style, { fontSize: px(node.size), fontWeight: node.weight, lineHeight: px(node.lineHeight), color: node.color, textAlign: node.align });
      el.textContent = node.text;
    }
    if (node.type === 'group') {
      if (node.children.some(n => n.isMask)) style.overflow = 'hidden';
      for (const child of node.children) el.append(make(child));
    }
    return el;
  }
  function show(index) {
    selected = index;
    select.value = String(index);
    const board = scene.boards[index];
    root.replaceChildren(...board.children.map(make));
    root.style.width = px(board.w); root.style.height = px(board.h);
    root.dataset.board = board.name; root.dataset.mobile = String(board.mobile);
    fit();
    const mobile = board.mobile;
    const find = name => scene.boards.findIndex(b => b.mobile === mobile && b.name.startsWith(name));
    if (!renderOnly) {
      const targets = [
        ['Кнопка / Загрузить документ', 'Показать демонстрационный документ', () => show(find('02 /'))],
        ['Кнопка / Заменить', 'Вернуться к загрузке', () => show(find('01 /'))],
        ['Справка / кнопка', 'Открыть или закрыть справку', () => show(find(board.name.startsWith('09 /') ? '01 /' : '09 /'))],
      ];
      for (const [name, label, action] of targets) {
        const target = [...root.querySelectorAll('[data-name]')].find(el => el.dataset.name === name);
        if (!target) continue;
        const button = document.createElement('button');
        button.className = 'layer hotspot'; button.type = 'button'; button.ariaLabel = label;
        Object.assign(button.style, { left: target.style.left, top: target.style.top, width: target.style.width, height: target.style.height });
        button.onclick = action; target.parentElement.append(button);
      }
    }
    window.currentBoardIndex = index;
    window.previewReady = Promise.all([document.fonts.ready, ...[...root.querySelectorAll('img')].map(image => image.decode())]);
    return window.previewReady;
  }
  function fit() {
    const board = scene.boards[selected];
    const scale = renderOnly ? 1 : Math.min(1, innerWidth / board.w);
    root.style.transform = `scale(${scale})`;
    viewport.style.width = px(board.w * scale); viewport.style.height = px(board.h * scale);
  }
  scene.boards.forEach((board, i) => { const option = document.createElement('option'); option.value = i; option.textContent = `${board.mobile ? 'Mobile' : 'Desktop'} · ${board.name}`; select.append(option); });
  select.onchange = () => show(Number(select.value));
  document.getElementById('show-home').onclick = () => show(scene.boards[selected].mobile ? 9 : 0);
  document.getElementById('show-work').onclick = () => show(scene.boards[selected].mobile ? 10 : 1);
  window.addEventListener('resize', fit);
  window.showBoard = show;
  show(selected);
})();
